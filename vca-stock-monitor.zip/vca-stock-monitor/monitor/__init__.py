"""VCA Stock Monitor."""
